package com.github.chrisjunior.loginapp;

import java.util.Scanner;

/**
 * Console entry point for the application.
 *
 * <p>This class demonstrates:
 * - input using Scanner
 * - output using System.out.println()
 * - decisions through validation and login checks
 * - object-oriented design using User and Login classes
 */
public final class App {

    private App() {
        // Prevent instantiation because this class only contains the main entry point.
    }

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("=== Account Registration ===");

            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine().trim();

            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine().trim();

            System.out.print("Enter username: ");
            String username = scanner.nextLine().trim();

            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            System.out.print("Enter South African cell phone number (example: +27838968976): ");
            String cellPhoneNumber = scanner.nextLine().trim();

            User user = new User(firstName, lastName, username, password, cellPhoneNumber);
            Login login = new Login(user);

            // Show the individual validation messages so the user receives detailed feedback.
            System.out.println(login.getUsernameMessage());
            System.out.println(login.getPasswordMessage());
            System.out.println(login.getCellPhoneMessage());

            String registrationResult = login.registerUser();
            System.out.println(registrationResult);

            // Stop the program early if registration failed. This is a decision point.
            if (!"User has been registered successfully.".equals(registrationResult)) {
                return;
            }

            System.out.println();
            System.out.println("=== Login ===");
            System.out.print("Enter username: ");
            String enteredUsername = scanner.nextLine().trim();

            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine();

            login.loginUser(enteredUsername, enteredPassword);
            System.out.println(login.returnLoginStatus());
        }
    }
}
